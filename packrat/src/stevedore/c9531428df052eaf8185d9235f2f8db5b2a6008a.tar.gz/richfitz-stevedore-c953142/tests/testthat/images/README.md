# Stevedore test images

These are build files for test images - I doubt any will do anything interesting.  All are built with the tag `richfitz/<dirname>` (e.g., `richfitz/iterate`) and are designed to test some feature of the package on run or build.

* `[iterate]`: echo a message to the console a number of times, with pauses

Build all images using `./build.sh`
