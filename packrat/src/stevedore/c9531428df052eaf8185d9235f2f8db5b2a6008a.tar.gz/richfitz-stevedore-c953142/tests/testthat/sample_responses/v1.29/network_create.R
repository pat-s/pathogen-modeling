## version: 1.29
## method: post
## path: /networks/create
## code: 201
## response: {"Id":"22be93d5babb089c5aab8dbc369042fad48ff791584ca2da2100db837a1c7c30","Warning":""}
list(
  id = "22be93d5babb089c5aab8dbc369042fad48ff791584ca2da2100db837a1c7c30",
  warning = "")
