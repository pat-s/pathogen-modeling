## version: 1.26
## method: get
## path: /_ping
## code: 200
## response: OK
"OK"
