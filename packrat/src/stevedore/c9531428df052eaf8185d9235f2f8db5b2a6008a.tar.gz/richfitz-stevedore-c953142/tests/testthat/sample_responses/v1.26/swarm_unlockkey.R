## version: 1.26
## method: get
## path: /swarm/unlockkey
## code: 200
## response: {"UnlockKey":"SWMKEY-1-7c37Cc8654o6p38HnroywCi19pllOnGtbdZEgtKxZu8"}
list(
  unlock_key = "SWMKEY-1-7c37Cc8654o6p38HnroywCi19pllOnGtbdZEgtKxZu8")
