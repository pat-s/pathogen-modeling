## version: 1.32
## method: post
## path: /containers/{id}/wait
## code: 200
## response: {"StatusCode": 0}
list(status_code = 0L)
