## version: 1.30
## method: post
## path: /containers/{id}/update
## code: 200
## response: {"Warnings": ["string"]}
list(warnings = "string")
