## version: 1.31
## method: get
## path: /_ping
## code: 200
## response: OK
"OK"
