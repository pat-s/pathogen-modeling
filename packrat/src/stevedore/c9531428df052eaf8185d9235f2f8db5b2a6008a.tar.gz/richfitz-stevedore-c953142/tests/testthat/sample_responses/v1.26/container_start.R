## version: 1.26
## method: post
## path: /containers/{id}/start
## code: 204
## response: ~
NULL
