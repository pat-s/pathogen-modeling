## version: 1.30
## method: get
## path: /version
## code: 200
## response: {"Version":"17.04.0","Os":"linux","KernelVersion":"3.19.0-23-generic","GoVersion":"go1.7.5","GitCommit":"deadbee","Arch":"amd64","ApiVersion":"1.27","MinAPIVersion":"1.12","BuildTime":"2016-06-14T07:09:13.444803460+00:00","Experimental":true}
list(
  version = "17.04.0",
  api_version = "1.27",
  min_api_version = "1.12",
  git_commit = "deadbee",
  go_version = "go1.7.5",
  os = "linux",
  arch = "amd64",
  kernel_version = "3.19.0-23-generic",
  experimental = TRUE,
  build_time = "2016-06-14T07:09:13.444803460+00:00")
