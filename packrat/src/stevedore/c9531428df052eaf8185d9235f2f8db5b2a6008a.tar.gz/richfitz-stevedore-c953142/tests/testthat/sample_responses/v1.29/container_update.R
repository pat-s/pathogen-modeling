## version: 1.29
## method: post
## path: /containers/{id}/update
## code: 200
## response: {"Warnings": ["string"]}
list(warnings = "string")
