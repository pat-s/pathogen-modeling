## version: 1.30
## method: post
## path: /containers/prune
## code: 200
## response: {"ContainersDeleted": ["string"],"SpaceReclaimed": 0}
list(containers_deleted = "string", space_reclaimed = 0L)
