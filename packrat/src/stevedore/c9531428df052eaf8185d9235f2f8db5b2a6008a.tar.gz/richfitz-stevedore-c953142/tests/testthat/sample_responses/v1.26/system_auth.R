## version: 1.26
## method: post
## path: /auth
## code: 200
## response: {"Status":"Login Succeeded","IdentityToken":"9cbaf023786cd7..."}
list(status = "Login Succeeded", identity_token = "9cbaf023786cd7...")
