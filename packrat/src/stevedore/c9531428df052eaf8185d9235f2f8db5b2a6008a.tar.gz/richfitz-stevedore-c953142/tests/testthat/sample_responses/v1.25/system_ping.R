## version: 1.25
## method: get
## path: /_ping
## code: 200
## response: OK
"OK"
