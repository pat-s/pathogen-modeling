## version: 1.26
## method: post
## path: /containers/{id}/wait
## code: 200
## response: {"StatusCode": 0}
list(status_code = 0L)
