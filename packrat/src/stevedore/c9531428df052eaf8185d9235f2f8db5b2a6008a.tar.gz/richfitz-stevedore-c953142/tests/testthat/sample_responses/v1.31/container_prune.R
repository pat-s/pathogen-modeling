## version: 1.31
## method: post
## path: /containers/prune
## code: 200
## response: {"ContainersDeleted": ["string"],"SpaceReclaimed": 0}
list(containers_deleted = "string", space_reclaimed = 0L)
