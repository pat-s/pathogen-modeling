## version: 1.29
## method: post
## path: /services/create
## code: 201
## response: {"ID":"ak7w3gjqoa3kuz8xcpnyy0pvl","Warning":"unable to pin image doesnotexist:latest to digest: image library/doesnotexist:latest not found"}
list(
  id = "ak7w3gjqoa3kuz8xcpnyy0pvl",
  warning = "unable to pin image doesnotexist:latest to digest: image library/doesnotexist:latest not found")
