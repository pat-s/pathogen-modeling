## version: 1.29
## method: post
## path: /containers/create
## code: 201
## response: {"Id":"e90e34656806","Warnings":[]}
list(id = "e90e34656806",
     warnings = character())
