## version: 1.30
## method: get
## path: /_ping
## code: 200
## response: OK
"OK"
