## version: 1.28
## method: get
## path: /_ping
## code: 200
## response: OK
"OK"
