## version: 1.32
## method: post
## path: /secrets/create
## code: 201
## response: {"ID":"ktnbjxoalbkvbvedmg1urrz8h"}
list(id = "ktnbjxoalbkvbvedmg1urrz8h")
