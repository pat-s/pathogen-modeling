## version: 1.31
## method: post
## path: /build/prune
## code: 200
## response: {"SpaceReclaimed": 0}
list(space_reclaimed = 0L)
