## version: 1.25
## method: post
## path: /volumes/prune
## code: 200
## response: {"VolumesDeleted": ["string"],"SpaceReclaimed": 0}
list(volumes_deleted = "string", space_reclaimed = 0L)
