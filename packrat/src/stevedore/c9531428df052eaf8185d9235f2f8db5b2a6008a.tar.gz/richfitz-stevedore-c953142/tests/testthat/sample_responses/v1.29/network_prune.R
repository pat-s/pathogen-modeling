## version: 1.29
## method: post
## path: /networks/prune
## code: 200
## response: {"NetworksDeleted": ["string"]}
list(networks_deleted = "string")
