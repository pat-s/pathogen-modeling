library(testthat)
library(stevedore)

test_check("stevedore")
