library(testthat)
library(RSAGA)
library(rgdal)

test_check("RSAGA")
