distTot<-function(pts,decdeg=FALSE){
sum(distNode(pts,decdeg=decdeg))
}
