
context("sysreqs")

test_that("sysreqs works", {

  expect_true(TRUE)

})
