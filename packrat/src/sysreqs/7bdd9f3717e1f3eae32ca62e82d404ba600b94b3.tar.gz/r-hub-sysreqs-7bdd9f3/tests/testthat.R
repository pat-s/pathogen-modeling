library(testthat)
library(sysreqs)

test_check("sysreqs")
