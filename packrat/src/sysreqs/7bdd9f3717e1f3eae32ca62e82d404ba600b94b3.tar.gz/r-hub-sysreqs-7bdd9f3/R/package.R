
#' Install SystemRequirements of Packages
#'
#' Automatically download and install system requirements of R packages.
#'
#' @docType package
#' @name sysreqs
NULL
