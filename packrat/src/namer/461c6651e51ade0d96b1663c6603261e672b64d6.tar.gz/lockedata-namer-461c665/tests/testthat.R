library(testthat)
library(namer)

test_check("namer")
