## Test environments
* local x86_64-w64-mingw32/x64 install, R 3.5.0
* rhub::check_for_cran

## R CMD check results

0 errors | 0 warnings | 0 note

## Release summary

This is a re-submission taking into account your feedback. Thanks a lot!

* file.edit() in examples is inside if(interactive()){} now.
