
library(anytime)

print(anytime(c("2017-04-02 11:12:13.456", "1971-10-31", "1971-11-01"), tz="Europe/London", useR=TRUE))
