math <- function(x){
    ## enclose some x in math dollars
    return(paste("$", x, "$", sep = ""))
    }


