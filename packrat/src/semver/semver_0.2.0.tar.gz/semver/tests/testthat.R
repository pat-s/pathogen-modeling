library(testthat)
library(semver)

test_check("semver")
