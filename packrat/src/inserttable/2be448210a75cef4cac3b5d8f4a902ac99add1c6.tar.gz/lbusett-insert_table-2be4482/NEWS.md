# inserttable 0.0.2

* Now also working in plain ".R" files to support use in `knitr::spin`
* Added possibility to provide user defined table name in the GUI

# inserttable 0.0.1

First stable version

# inserttable 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.
