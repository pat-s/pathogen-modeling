library(testthat)
library(GREA)

test_check("GREA")
