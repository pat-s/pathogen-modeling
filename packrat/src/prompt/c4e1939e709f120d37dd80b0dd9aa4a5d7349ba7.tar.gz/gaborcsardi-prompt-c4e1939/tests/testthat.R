library(testthat)
library(prompt)

test_check("prompt")
