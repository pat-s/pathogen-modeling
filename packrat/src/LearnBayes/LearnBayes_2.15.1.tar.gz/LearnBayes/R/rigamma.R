rigamma = function(n, a, b) {
        return(1/rgamma(n, shape = a, rate = b))
    }
