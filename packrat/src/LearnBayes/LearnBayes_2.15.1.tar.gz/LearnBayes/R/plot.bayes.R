plot.bayes=function(x,...)
  barplot(x$prob,...)