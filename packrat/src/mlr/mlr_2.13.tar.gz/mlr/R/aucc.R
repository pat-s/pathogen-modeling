# load_all()

# calcAUCCScores = function(pred, measure, cl) {
  # cls = pred$task.desc$class.levels
  # p = getPredictionProbabilities(pred, classes = cls)
  # maxs = apply(p, 1L, max)
  # o = order(maxs)


# }
