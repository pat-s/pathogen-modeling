#' @param models (`logical(1)`)\cr
#'   Should all fitted models be stored in the [ResampleResult]?
#'   Default is `TRUE`.
#' @md
