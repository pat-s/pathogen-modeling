#' @param aggregation (`character(1)`) \cr
#'   \dQuote{mean} or \dQuote{default}. See [getBMRAggrPerformances]
#'   for details on \dQuote{default}.
#' @md
