#' @return [data.frame] | [Task]. Same type as `obj`.
#' @md
