#' @return [Learner].
#' @md
