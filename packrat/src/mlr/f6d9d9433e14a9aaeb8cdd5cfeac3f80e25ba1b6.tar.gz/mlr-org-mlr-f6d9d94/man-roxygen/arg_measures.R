#' @param measures ([Measure] | list of [Measure])\cr
#'   Performance measure(s) to evaluate.
#'   Default is the default measure for the task, see here [getDefaultMeasure].
#' @md
