#' @param cv.folds (`integer(1)`)\cr
#'  The number of folds for the inner cross validation method to predict labels for the augmented feature space. Default is `2`.
#'
