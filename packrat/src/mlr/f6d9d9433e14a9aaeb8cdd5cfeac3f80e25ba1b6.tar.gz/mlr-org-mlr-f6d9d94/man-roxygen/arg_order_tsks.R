#' @param order.tsks (`character(n.tasks)`)\cr
#'   Character vector with `task.ids` in new order.
#' @md
