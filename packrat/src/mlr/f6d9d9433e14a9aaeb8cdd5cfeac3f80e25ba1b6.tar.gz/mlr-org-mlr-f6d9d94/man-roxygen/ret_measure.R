#' @return [Measure].
#' @md
