#' @param res ([FeatSelResult])\cr
#'   The result of of [selectFeatures].
#' @md
