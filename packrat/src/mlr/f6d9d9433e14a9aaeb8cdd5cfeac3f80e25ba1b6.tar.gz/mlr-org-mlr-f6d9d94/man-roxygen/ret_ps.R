#' @return [ParamSet].
#' @md
