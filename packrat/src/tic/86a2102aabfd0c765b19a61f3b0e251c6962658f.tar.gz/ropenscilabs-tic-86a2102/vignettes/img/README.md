# How to open/modify `.graphml` files

This filetype is specfic for the application [yEd](https://www.yworks.com/yed).
You can install the application locally or use the [live version](https://www.yworks.com/products/yed-live).
