library(testthat)
library(datapasta)

test_check("datapasta")
