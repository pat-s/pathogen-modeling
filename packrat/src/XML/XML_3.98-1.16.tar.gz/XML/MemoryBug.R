library(SSOAP)
 # Run this twice.
w = processWSDL("http://ops.epo.org/wsdl/ops.wsdl")
